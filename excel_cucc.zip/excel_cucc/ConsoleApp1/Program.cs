﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Compression;
using System.IO;
using MailChimp.Net.Models;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string sourceFile = @"C:\csapat2xdd\vedett.xlsx";

            System.IO.FileInfo fi = new System.IO.FileInfo(sourceFile);
            if (fi.Exists)
            {
                fi.MoveTo(@"C:\csapat2xdd\vedett.zip");
                Console.WriteLine("A módosítás zip-re megtörtént.");
                
            }

            string zipFilePath = @"C:\csapat2xdd\vedett.zip";
            string extractionPath = @"C:\csapat2xdd\kulon";
            ZipFile.ExtractToDirectory(zipFilePath, extractionPath);
            Console.WriteLine("A kicsomagolás megtörtént!!!%!554");

            //string filePath = @"C:\csapat2xdd\xl\worksheets\sheet1.xml";
            //List<string> lines = new List<string>();
            //string lines = File.ReadAllText(filePath);
            //string itemcode = "<sheetProtection algorithmName='SHA - 512' hashValue='X5jfEn1khsMKwHagQb3C2J7IFgKs + SqGEQYYTa940PefIyoIDUHTq++h9W / j0oU9UxuFoiw8lVC0QMaqiSmEag == ' saltValue='77cHxK8XIdk7NN7oEYpV / g == ' spinCount='100000' sheet='1' formatCells='0' formatColumns='0' formatRows='0' insertColumns='0' insertRows='0' insertHyperlinks='0' deleteColumns='0' deleteRows='0' sort='0' autoFilter='0' pivotTables='0'/><pageMargins left='0.7' right='0.7' top='0.75' bottom='0.75' header='0.3' footer='0.3'/>";
            //lines.Remove(itemcode);
            //string startTag = "</sheetData>";
            //string endTag = "</worksheet>";
            //int startIndex = filePath.IndexOf(startTag) + startTag.Length;
            //Console.WriteLine(filePath.Substring(startIndex, filePath.IndexOf(endTag)-startIndex));
            //Console.WriteLine("Sheet eltünt pukk!");
            //File.WriteAllLines(filePath, lines);
            //lines = lines.Replace("</sheetData>"+ 473 + "</ worksheet >", "");
            //Console.WriteLine(filePath);
            //lines.Remove("<sheetProtection algorithmName='SHA - 512' hashValue='X5jfEn1khsMKwHagQb3C2J7IFgKs + SqGEQYYTa940PefIyoIDUHTq++h9W / j0oU9UxuFoiw8lVC0QMaqiSmEag == ' saltValue='77cHxK8XIdk7NN7oEYpV / g == ' spinCount='100000' sheet='1' formatCells='0' formatColumns='0' formatRows='0' insertColumns='0' insertRows='0' insertHyperlinks='0' deleteColumns='0' deleteRows='0' sort='0' autoFilter='0' pivotTables='0'/><pageMargins left='0.7' right='0.7' top='0.75' bottom='0.75' header='0.3' footer='0.3'/>");
            //Console.WriteLine(lines);

            ZipFile.CreateFromDirectory(@"C:\csapat2xdd\kulon",extractionPath);
            

            Console.ReadKey();
        }
    }
}
