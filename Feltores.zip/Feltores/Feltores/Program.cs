﻿using System;
using System.IO;
namespace Feltores
{
    class Program
    {
        static void Main(string[] args)
        {
            Kiolvas("vedett/xl/worksheets/sheet1.xml");
            Console.ReadKey();
        }
        static void Kiolvas(string fajl)
        {
            string szoveg = File.ReadAllText(fajl);
            string[] szavak = szoveg.Split('<');
            for (int j = 0; j < szavak.Length; j++)
            {
                if (szavak[j].Contains("sheetProtection") || szavak[j].Contains("pageMargins"))
                {
                    szavak[j] = "";
                }
            }
            szoveg = "";
            for (int i = 0; i < szavak.Length; i++)
            {
                if (szavak[i]!="")
                {
                    szoveg += "<" + szavak[i];
                }
            }
            Console.WriteLine(szoveg);
            File.WriteAllText(fajl,szoveg);
        }
    }
}
